import utils
import pandas


def main():
    eng_sent, eng_labels = utils.read_conll("data/datasets/baseline/en_ewt_nn_train_newsgroup_and_weblogs.conll")
    germ_sent, germ_labels = utils.read_conll("data/datasets/NoSta-D/NER-de-train.tsv")
    
    print(eng_sent[:10])





if __name__ == '__main__':
    main()