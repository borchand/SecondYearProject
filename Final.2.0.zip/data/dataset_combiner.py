

def combine_data(from_paths, to_path):
    with open(to_path, "w") as out_file:    
        for path in from_paths:
            with open(path, "r") as in_file:
                data = in_file.read()
            out_file.write(data)



def main():
    to_combine = [
        "datasets/baseline/en_ewt_nn_newsgroup_test.conll",
        "datasets/baseline/en_ewt_nn_weblogs_test.conll"
    ]
    combine_data(to_combine, "datasets/baseline/en_ewt_nn_test_newsgroup_and_weblogs.conll")


if __name__ == '__main__':
    main()